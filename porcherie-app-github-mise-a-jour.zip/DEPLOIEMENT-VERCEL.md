﻿# Déployer l'application porcherie sur Vercel depuis GitHub

## 1. Verifier GitHub

Le dépôt GitHub doit contenir les fichiers de l'application porcherie :

- `index.html`
- `styles.css`
- `app.js`
- `README.md`

Si ces fichiers sont dans un dossier `porcherie-app`, il faudra indiquer ce dossier comme dossier racine dans Vercel.

## 2. Aller sur Vercel

1. Ouvrir https://vercel.com
2. Se connecter avec le compte GitHub
3. Autoriser Vercel a acceder au compte GitHub

## 3. Importer le projet

1. Cliquer sur `Add New`
2. Choisir `Project`
3. Sélectionner le dépôt GitHub de l'application
4. Cliquer sur `Import`

## 4. Réglages du projet

Si les fichiers `index.html`, `styles.css` et `app.js` sont a la racine du dépôt :

- Framework Preset : `Other`
- Build Command : laisser vide
- Output Directory : laisser vide ou mettre `.`

Si les fichiers sont dans le dossier `porcherie-app` :

- Root Directory : `porcherie-app`
- Framework Preset : `Other`
- Build Command : laisser vide
- Output Directory : laisser vide ou mettre `.`

## 5. Déployer

Cliquer sur `Deploy`.

Vercel va creer une adresse publique du type :

`https://nom-du-projet.vercel.app`

## 6. Apres le déploiement

A chaque modification envoyee sur GitHub, Vercel redeploiera automatiquement l'application.

