﻿# Application de gestion de porcherie

Ce dossier contient une version restaurée du prototype de gestion de porcherie.

## Modules

- Tableau de bord
- Cheptel
- Reproduction
- Santé animale
- Consommation aliment et eau
- Pesées périodiques
- Performances : indice de consommation, GMQ, taux de mortalité
- Stocks
- Ventes
- Finances
- Tâches quotidiennes
- Nouvelle opération
- Paramètres de la ferme
- Utilisateurs et accès par rôle

## Fichiers

- `index.html`
- `styles.css`
- `app.js`

Ouvrir `index.html` dans un navigateur moderne, ou servir ce dossier en local.


