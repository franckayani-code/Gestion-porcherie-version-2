﻿const modules = [
  ["dashboard", "Tableau", "Vue d'ensemble"],
  ["herd", "Cheptel", "Cheptel"],
  ["reproduction", "Reproduction", "Reproduction"],
  ["health", "Santé", "Santé animale"],
  ["consumption", "Consommation", "Consommation aliment et eau"],
  ["weighing", "Pesées", "Pesées périodiques"],
  ["performance", "Performances", "Performances"],
  ["stock", "Stocks", "Stocks"],
  ["sales", "Ventes", "Ventes"],
  ["finance", "Finances", "Finances"],
  ["tasks", "Tâches", "Tâches quotidiennes"],
  ["quick", "Nouvelle opération", "Nouvelle opération"],
  ["settings", "Paramètres", "Paramètres"],
];

const rows = {
  herd: [
    ["T-014", "Truie", "Gestation", "B2", "184 kg"],
    ["V-003", "Verrat", "Actif", "A1", "232 kg"],
    ["P-06", "Lot porcelets", "Actif", "Nurserie", "8,1 kg moy."],
    ["E-03", "Lot engraissement", "Actif", "C1", "61 kg moy."],
    ["T-021", "Truie", "Sous retrait", "Quarantaine", "176 kg"],
  ],
  consumption: [
    ["B2", "Truie T-014", "5,8 kg", "32 L", "Eau en baisse"],
    ["C1", "Lot E-03", "286 kg", "1 180 L", "Aliment élevé"],
    ["Nurserie", "Lot P-06", "94 kg", "420 L", "Normal"],
    ["A1", "Verrat V-003", "3,2 kg", "18 L", "Normal"],
  ],
  performance: [
    ["P-06", "2,4", "410 g", "1,2%", "Correct"],
    ["E-03", "2,9", "615 g", "3,1%", "À surveiller"],
    ["E-04", "3,3", "520 g", "4,8%", "Risque élevé"],
  ],
  sales: [
    ["12 juin", "Boucherie Kivu", "14 porcs", "4 760 000", "Payé"],
    ["09 juin", "Mme Diallo", "8 porcelets", "640 000", "Partiel"],
    ["03 juin", "Grossiste Lemba", "Lot E-02", "7 200 000", "Payé"],
  ],
};

const cards = {
  reproduction: [
    ["Mise bas prévue", "T-014", "18 juin 2026", "Loge B2"],
    ["Diagnostic gestation", "T-028", "20 juin 2026", "Saillie V-003"],
    ["Sevrage prevu", "T-011", "22 juin 2026", "Lot P-05"],
  ],
  stock: [
    ["Critique", "Aliment croissance", "320 kg disponible"],
    ["Normal", "Aliment truies", "1 240 kg disponible"],
    ["À surveiller", "Vermifuge", "12 doses disponibles"],
    ["Normal", "Vaccin porcelets", "28 doses disponibles"],
    ["Normal", "Désinfectant", "18 litres disponibles"],
    ["Normal", "Sacs de son", "31 sacs disponibles"],
  ],
  tasks: [
    ["Terminé", "Nourrir lot E-03", "Aujourd'hui 07:00"],
    ["À faire", "Nettoyer loge B2", "Aujourd'hui 09:30"],
    ["Urgent", "Controler T-014", "Aujourd'hui 16:00"],
    ["À faire", "Commander aliment", "Demain"],
    ["Planifié", "Peser lot P-06", "20 juin"],
    ["À faire", "Relancer paiement", "21 juin"],
  ],
};

const accessRules = [
  ["Propriétaire / Manager", "Tous les modules, paramètres, utilisateurs, rapports", "Aucun"],
  ["Comptable", "Ventes, finances, paiements, dépenses, rapports financiers", "Santé détaillée, traitements, paramètres techniques"],
  ["Gérant de ferme", "Cheptel, reproduction, santé, consommation, pesées, stocks, tâches, opérations", "Finances complètes et gestion des utilisateurs"],
  ["Vétérinaire / Technicien", "Santé, traitements, vaccinations, mortalité, pesées, performances", "Ventes, finances, paramètres"],
  ["Employé de ferme", "Tâches, opérations limitées, aliment, eau, pesées, signalements", "Finances, ventes, rapports complets, paramètres"],
  ["Commercial", "Ventes, clients, paiements, lots disponibles", "Santé détaillée, coûts internes, paramètres"],
  ["Lecture seule", "Tableau de bord résumé, rapports validés, indicateurs globaux", "Ajout, modification, suppression"],
];

const defaultUsers = [
  { name: "Manager principal", contact: "", role: "Propriétaire / Manager" },
  { name: "Comptable", contact: "", role: "Comptable" },
];

function makeButton([id, label]) {
  const button = document.createElement("button");
  button.type = "button";
  button.dataset.view = id;
  button.textContent = label;
  button.addEventListener("click", () => setView(id));
  return button;
}

function setView(id) {
  document.querySelectorAll(".view").forEach((view) => view.classList.toggle("active", view.id === id));
  document.querySelectorAll("[data-view]").forEach((button) => button.classList.toggle("active", button.dataset.view === id));
  const mod = modules.find(([moduleId]) => moduleId === id);
  document.getElementById("module-label").textContent = mod?.[1] || "";
  document.getElementById("module-title").textContent = mod?.[2] || "";
}

function renderTable(id, data) {
  const table = document.getElementById(`${id}-table`);
  if (!table) return;
  table.innerHTML = data.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join("")}</tr>`).join("");
}

function renderCards(id, data) {
  const root = document.getElementById(`${id}-cards`);
  if (!root) return;
  root.innerHTML = data.map(([tag, title, detail, note]) => `
    <article class="card">
      <p class="eyebrow">${tag}</p>
      <strong>${title}</strong>
      <small>${detail}</small>
      ${note ? `<p>${note}</p>` : ""}
    </article>
  `).join("");
}

document.getElementById("side-nav").append(...modules.map(makeButton));
document.getElementById("module-tabs").append(...modules.map(makeButton));
const shortLabels = {
  dashboard: "Tableau",
  reproduction: "Repro",
  consumption: "Conso",
  performance: "Perf.",
  quick: "Opération",
  settings: "Réglages",
};
document.getElementById("bottom-nav").append(...modules.map(([id, label]) => makeButton([id, shortLabels[id] || label])));

Object.entries(rows).forEach(([id, data]) => renderTable(id, data));
Object.entries(cards).forEach(([id, data]) => renderCards(id, data));
renderTable("access", accessRules);

document.getElementById("health-list").innerHTML = [
  ["T-021 - Fievre legere", "Traitement en cours depuis 2 jours"],
  ["Lot E-03 - Toux observee", "Surveillance renforcee"],
  ["P-06 - Vaccination", "Rappel prevu demain"],
].map(([title, note]) => `<div class="line warn"><strong>${title}</strong><small>${note}</small></div>`).join("");

document.getElementById("weighing-list").innerHTML = [
  ["Lot P-06 - 8,1 kg moyen", "84 porcelets. Prochaine pesée : 24 juin"],
  ["Lot E-03 - 61 kg moyen", "Objectif vente : 95 kg"],
  ["T-014 - 184 kg", "Suivi avant mise bas"],
].map(([title, note]) => `<div class="line warn"><strong>${title}</strong><small>${note}</small></div>`).join("");

document.getElementById("open-entry").addEventListener("click", () => setView("quick"));
document.getElementById("open-settings").addEventListener("click", () => setView("settings"));
document.querySelectorAll(".quick-actions button").forEach((button) => button.addEventListener("click", () => setView("quick")));

const farmDefaults = { name: "Ferme Mbandaka", country: "", currency: "FCFA" };

function getFarmProfile() {
  try {
    return { ...farmDefaults, ...JSON.parse(localStorage.getItem("porcherieFarmProfile") || "{}") };
  } catch {
    return farmDefaults;
  }
}

function updateFarmProfileView() {
  const profile = getFarmProfile();
  document.getElementById("farm-name-display").textContent = profile.name || farmDefaults.name;
  document.getElementById("farm-name-input").value = profile.name || "";
  document.getElementById("farm-country-input").value = profile.country || "";
  document.getElementById("farm-currency-input").value = profile.currency || "";
  document.getElementById("farm-summary-name").textContent = profile.name || "Non renseigné";
  document.getElementById("farm-summary-country").textContent = profile.country || "Non renseigné";
  document.getElementById("farm-summary-currency").textContent = profile.currency || "Non renseigné";
}

document.getElementById("farm-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const profile = {
    name: document.getElementById("farm-name-input").value.trim() || farmDefaults.name,
    country: document.getElementById("farm-country-input").value.trim(),
    currency: document.getElementById("farm-currency-input").value.trim() || farmDefaults.currency,
  };
  localStorage.setItem("porcherieFarmProfile", JSON.stringify(profile));
  updateFarmProfileView();
});

function getUsers() {
  try {
    return JSON.parse(localStorage.getItem("porcherieUsers") || "null") || defaultUsers;
  } catch {
    return defaultUsers;
  }
}

function getRoleAccess(role) {
  return accessRules.find(([ruleRole]) => ruleRole === role)?.[1] || "Accès personnalisé";
}

function renderUsers() {
  const users = getUsers();
  document.getElementById("users-table").innerHTML = users.map((user) => `
    <tr>
      <td>${user.name}</td>
      <td>${user.role}</td>
      <td>${getRoleAccess(user.role)}</td>
    </tr>
  `).join("");
}

document.getElementById("user-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const name = document.getElementById("user-name-input").value.trim();
  if (!name) return;
  const users = getUsers();
  users.push({
    name,
    contact: document.getElementById("user-contact-input").value.trim(),
    role: document.getElementById("user-role-input").value,
  });
  localStorage.setItem("porcherieUsers", JSON.stringify(users));
  event.target.reset();
  renderUsers();
});

let draggedIndicator = null;
document.querySelectorAll(".indicator-card").forEach((card) => {
  card.addEventListener("dragstart", () => {
    draggedIndicator = card;
    card.classList.add("dragging");
  });
  card.addEventListener("dragend", () => {
    card.classList.remove("dragging");
    draggedIndicator = null;
  });
  card.addEventListener("dragover", (event) => {
    event.preventDefault();
    if (!draggedIndicator || draggedIndicator === card) return;
    const board = document.getElementById("indicator-board");
    const rect = card.getBoundingClientRect();
    const insertAfter = event.clientY > rect.top + rect.height / 2 || event.clientX > rect.left + rect.width / 2;
    board.insertBefore(draggedIndicator, insertAfter ? card.nextSibling : card);
  });
});
updateFarmProfileView();
renderUsers();
setView("dashboard");


