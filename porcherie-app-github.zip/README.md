# Application de gestion de porcherie

Ce dossier contient une version restauree du prototype de gestion de porcherie.

## Modules

- Tableau de bord
- Cheptel
- Reproduction
- Sante animale
- Consommation aliment et eau
- Pesees periodiques
- Performances : indice de consommation, GMQ, taux de mortalite
- Stocks
- Ventes
- Finances
- Taches quotidiennes
- Saisie rapide

## Fichiers

- `index.html`
- `styles.css`
- `app.js`

Ouvrir `index.html` dans un navigateur moderne, ou servir ce dossier en local.
