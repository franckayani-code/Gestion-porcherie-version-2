const modules = [
  ["dashboard", "Tableau", "Vue d'ensemble"],
  ["herd", "Cheptel", "Cheptel"],
  ["reproduction", "Reproduction", "Reproduction"],
  ["health", "Sante", "Sante animale"],
  ["consumption", "Consommation", "Consommation aliment et eau"],
  ["weighing", "Pesees", "Pesees periodiques"],
  ["performance", "Performances", "Performances"],
  ["stock", "Stocks", "Stocks"],
  ["sales", "Ventes", "Ventes"],
  ["finance", "Finances", "Finances"],
  ["tasks", "Taches", "Taches quotidiennes"],
  ["quick", "Saisie rapide", "Saisie rapide"],
];

const rows = {
  herd: [
    ["T-014", "Truie", "Gestation", "B2", "184 kg"],
    ["V-003", "Verrat", "Actif", "A1", "232 kg"],
    ["P-06", "Lot porcelets", "Actif", "Nurserie", "8,1 kg moy."],
    ["E-03", "Lot engraissement", "Actif", "C1", "61 kg moy."],
    ["T-021", "Truie", "Sous retrait", "Quarantaine", "176 kg"],
  ],
  consumption: [
    ["B2", "Truie T-014", "5,8 kg", "32 L", "Eau en baisse"],
    ["C1", "Lot E-03", "286 kg", "1 180 L", "Aliment eleve"],
    ["Nurserie", "Lot P-06", "94 kg", "420 L", "Normal"],
    ["A1", "Verrat V-003", "3,2 kg", "18 L", "Normal"],
  ],
  performance: [
    ["P-06", "2,4", "410 g", "1,2%", "Correct"],
    ["E-03", "2,9", "615 g", "3,1%", "A surveiller"],
    ["E-04", "3,3", "520 g", "4,8%", "Risque eleve"],
  ],
  sales: [
    ["12 juin", "Boucherie Kivu", "14 porcs", "4 760 000", "Paye"],
    ["09 juin", "Mme Diallo", "8 porcelets", "640 000", "Partiel"],
    ["03 juin", "Grossiste Lemba", "Lot E-02", "7 200 000", "Paye"],
  ],
};

const cards = {
  reproduction: [
    ["Mise bas prevue", "T-014", "18 juin 2026", "Loge B2"],
    ["Diagnostic gestation", "T-028", "20 juin 2026", "Saillie V-003"],
    ["Sevrage prevu", "T-011", "22 juin 2026", "Lot P-05"],
  ],
  stock: [
    ["Critique", "Aliment croissance", "320 kg disponible"],
    ["Normal", "Aliment truies", "1 240 kg disponible"],
    ["A surveiller", "Vermifuge", "12 doses disponibles"],
    ["Normal", "Vaccin porcelets", "28 doses disponibles"],
    ["Normal", "Desinfectant", "18 litres disponibles"],
    ["Normal", "Sacs de son", "31 sacs disponibles"],
  ],
  tasks: [
    ["Termine", "Nourrir lot E-03", "Aujourd'hui 07:00"],
    ["A faire", "Nettoyer loge B2", "Aujourd'hui 09:30"],
    ["Urgent", "Controler T-014", "Aujourd'hui 16:00"],
    ["A faire", "Commander aliment", "Demain"],
    ["Planifie", "Peser lot P-06", "20 juin"],
    ["A faire", "Relancer paiement", "21 juin"],
  ],
};

function makeButton([id, label]) {
  const button = document.createElement("button");
  button.type = "button";
  button.dataset.view = id;
  button.textContent = label;
  button.addEventListener("click", () => setView(id));
  return button;
}

function setView(id) {
  document.querySelectorAll(".view").forEach((view) => view.classList.toggle("active", view.id === id));
  document.querySelectorAll("[data-view]").forEach((button) => button.classList.toggle("active", button.dataset.view === id));
  const mod = modules.find(([moduleId]) => moduleId === id);
  document.getElementById("module-label").textContent = mod?.[1] || "";
  document.getElementById("module-title").textContent = mod?.[2] || "";
}

function renderTable(id, data) {
  const table = document.getElementById(`${id}-table`);
  if (!table) return;
  table.innerHTML = data.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join("")}</tr>`).join("");
}

function renderCards(id, data) {
  const root = document.getElementById(`${id}-cards`);
  if (!root) return;
  root.innerHTML = data.map(([tag, title, detail, note]) => `
    <article class="card">
      <p class="eyebrow">${tag}</p>
      <strong>${title}</strong>
      <small>${detail}</small>
      ${note ? `<p>${note}</p>` : ""}
    </article>
  `).join("");
}

document.getElementById("side-nav").append(...modules.map(makeButton));
document.getElementById("module-tabs").append(...modules.map(makeButton));
document.getElementById("bottom-nav").append(...modules.map(([id, label]) => makeButton([id, label.slice(0, 8)])));

Object.entries(rows).forEach(([id, data]) => renderTable(id, data));
Object.entries(cards).forEach(([id, data]) => renderCards(id, data));

document.getElementById("health-list").innerHTML = [
  ["T-021 - Fievre legere", "Traitement en cours depuis 2 jours"],
  ["Lot E-03 - Toux observee", "Surveillance renforcee"],
  ["P-06 - Vaccination", "Rappel prevu demain"],
].map(([title, note]) => `<div class="line warn"><strong>${title}</strong><small>${note}</small></div>`).join("");

document.getElementById("weighing-list").innerHTML = [
  ["Lot P-06 - 8,1 kg moyen", "84 porcelets. Prochaine pesee : 24 juin"],
  ["Lot E-03 - 61 kg moyen", "Objectif vente : 95 kg"],
  ["T-014 - 184 kg", "Suivi avant mise bas"],
].map(([title, note]) => `<div class="line warn"><strong>${title}</strong><small>${note}</small></div>`).join("");

document.getElementById("open-entry").addEventListener("click", () => setView("quick"));
document.querySelectorAll(".quick-actions button").forEach((button) => button.addEventListener("click", () => setView("quick")));
setView("dashboard");
